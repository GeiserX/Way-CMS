var _____WB$wombat$assign$function_____=function(name){return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name))||self[name];};if(!self.__WB_pmw){self.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opens = _____WB$wombat$assign$function_____("opens");
!function(t){var n=t(window),a=n.height();n.resize((function(){a=n.height()})),t.fn.parallax=function(o,r,i){var s,c,e=t(this);function l(){var i=n.scrollTop();e.each((function(){var n=t(this),l=n.offset().top;l+s(n)<i||l>i+a||!e.data("sppbparallax")||e.css("backgroundPosition",o+" "+Math.round((c-i)*r)+"px")}))}e.data("sppbparallax",!0),e.css("backgroundAttachment","fixed"),e.each((function(){c=e.offset().top})),s=i?function(t){return t.outerHeight(!0)}:function(t){return t.height()},(arguments.length<1||null===o)&&(o="50%"),(arguments.length<2||null===r)&&(r=.15),(arguments.length<3||null===i)&&(i=!0),n.bind("scroll",l).resize(l),l()},t.fn.parallaxDestroy=function(n,a){var o=t(this);o.data("sppbparallax")&&(n?o.css("backgroundPosition",n):o.css("backgroundPosition","0% 0%"),a?o.css("backgroundAttachment",a):o.css("backgroundAttachment","inherit"),o.data("sppbparallax",!1))}}(jQuery);
}
/*
     FILE ARCHIVED ON 01:25:21 Oct 03, 2024 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 11:04:42 Dec 13, 2025.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.725
  exclusion.robots: 0.098
  exclusion.robots.policy: 0.087
  esindex: 0.011
  cdx.remote: 7.041
  LoadShardBlock: 94.191 (3)
  PetaboxLoader3.datanode: 110.975 (4)
  load_resource: 21.033
*/